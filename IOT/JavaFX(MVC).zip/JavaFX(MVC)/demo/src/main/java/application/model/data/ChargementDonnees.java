package application.model.data;

public class ChargementDonnees {
    
}
